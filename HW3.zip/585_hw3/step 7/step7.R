install.packages("leaflet")

library("leaflet")

m<-leaflet()

m <- addTiles(m)

## hmm - VB! 
m <- addCircleMarkers(m, lng=-118.11670736799513, lat=34.063151467913315,label="TS Emporium", radius=2, fillOpacity=1.0,fill = TRUE, fillColor ="red")
m <- addCircleMarkers(m, lng=--118.12331942628929, lat=34.063893676381205,label="HK Good Fortune Supermarket",     radius=2, fillOpacity=1.0,fill = TRUE, fillColor ="red")
m <- addCircleMarkers(m, lng=-118.13270845806217, lat=34.063127895792505,label="Wing Hop Fung Monterey Park Store",      radius=2, fillOpacity=1.0,fill = TRUE, fillColor ="red")
m <- addCircleMarkers(m, lng=-118.13340278742332, lat=34.065343170723956,label="Ralphs", radius=2, fillOpacity=1.0,fill = TRUE, fillColor ="red")
m <- addCircleMarkers(m, lng=-118.1333900285599, lat=34.0637736020993,label="Ranch Market",     radius=2, fillOpacity=1.0,fill = TRUE, fillColor ="red")
m <- addCircleMarkers(m, lng=-118.13468255053643, lat=34.067373729893724,label="GW Supermarket",      radius=2, fillOpacity=1.0,fill = TRUE, fillColor ="red")
m <- addCircleMarkers(m, lng=-118.1340716433304, lat=34.067970418173715,label="Phoenix Food Boutique", radius=2, fillOpacity=1.0,fill = TRUE, fillColor ="red")
m <- addCircleMarkers(m, lng=-118.12928480687586, lat=34.06276439040307,label="Mama Lu's Dumpling House",     radius=2, fillOpacity=1.0,fill = TRUE, fillColor ="red")
m <- addCircleMarkers(m, lng=-118.12728461273822, lat=34.06280547409808,label="Kim Kee Noodle Cafe",      radius=2, fillOpacity=1.0,fill = TRUE, fillColor ="red")
m <- addCircleMarkers(m, lng=-118.13406274339253, lat=34.068475857496594,label="OK Cafe", radius=2, fillOpacity=1.0,fill = TRUE, fillColor ="red")
m <- addCircleMarkers(m, lng=-118.1340648601877, lat=34.068169465010456,label="Happy Family Restaurant",     radius=2, fillOpacity=1.0,fill = TRUE, fillColor ="red")
m <- addCircleMarkers(m, lng=-118.13404040780762, lat=34.06940806554021,label="Tasty Garden",      radius=2, fillOpacity=1.0,fill = TRUE, fillColor ="red")
m <- addCircleMarkers(m, lng=-118.1338677, lat=34.0681481,label="Ocean Front Walk", radius=2, fillOpacity=1.0,fill = TRUE, fillColor ="red")
print (m)