HW 5 Yucheng Yang 2333448896

Qustion 1:
Linear Regression Equation:
class =

     -0.1084 * CRIM +
      0.0458 * ZN +
      2.7187 * CHAS=1 +
    -17.376  * NOX +
      3.8016 * RM +
     -1.4927 * DIS +
      0.2996 * RAD +
     -0.0118 * TAX +
     -0.9465 * PTRATIO +
      0.0093 * B +
     -0.5226 * LSTAT +
     36.3411

There are 12 number of terms in the equation above.  The 11 terms are weight multiply features and the last one is intercept.
There are three features are not in the equation INDUS, AGE and CHAS due to the method we choose to build the equation.

Question 2:
Linear Regression Equation:
num_rings =
	sex=I          * -0.825 	+
	sex=M          * 0.058	+
	length         * -0.458	+
	diameter       * 11.075	+
	height         * 10.762   + 
	whole_weight   * 8.975    +
	shucked_weight * -19.787    +
	viscera_weight * -10.582   +
	shell_weight   * 8.742     +
	3.895

Question 3:
Linear Regression Equation:
num_rings =
	length		*	-11.933 +
	diameter	*	25.766 +
	height		*	20.358 +
	2.836